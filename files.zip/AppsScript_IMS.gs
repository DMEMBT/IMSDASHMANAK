/**
 * ============================================================
 *  IMS LIVE DASHBOARD + ORDER MANAGEMENT — Apps Script
 *  ----------------------------------------------------------
 *  Yeh script aapki Google Sheet ko JSON API mein convert karta hai
 *  taaki dashboard live data fetch + orders manage kar sake.
 *
 *  Setup steps:
 *  1. Apni Google Sheet open karo
 *  2. Extensions → Apps Script
 *  3. Default code delete karo, yeh poora code paste karo
 *  4. Save (Ctrl+S)
 *  5. Deploy → Manage Deployments → Pencil ✏️ → Version: New version → Deploy
 *  6. URL same rahega — dashboard auto reconnect ho jayega
 *
 *  Sheets required:
 *  - IMSDASH (inventory data — already exists)
 *  - Orders  (auto-create hoga first order pe)
 * ============================================================
 */

// ⚙️ CONFIGURE
const INVENTORY_SHEET = "IMSDASH";
const ORDERS_SHEET = "Orders";

const INVENTORY_COLUMNS = {
  name:  "Item Name",
  stock: "Stock",
  otw:   "OTW"
};

const ORDERS_HEADERS = ["Order ID", "Date", "Item Name", "Model", "Quantity", "Status", "Notes"];
const VALID_STATUSES = ["Pending", "Process", "Hold", "Cancelled", "Completed"];

// ============================================================
// ROUTING — doGet for fetching, doPost for cart/order actions
// ============================================================
function doGet(e) {
  const action = (e && e.parameter && e.parameter.action) || "inventory";
  return handle(action, e && e.parameter || {});
}

function doPost(e) {
  let body = {};
  try {
    body = JSON.parse(e.postData.contents);
  } catch (_) {
    return json({ ok: false, error: "Invalid JSON body" });
  }
  return handle(body.action, body);
}

function handle(action, params) {
  try {
    if (action === "inventory" || !action) {
      const items = getInventoryData();
      return json({
        ok: true,
        updatedAt: new Date().toISOString(),
        count: items.length,
        items: items
      });
    }
    if (action === "orders") {
      const orders = getOrders();
      return json({ ok: true, orders: orders, updatedAt: new Date().toISOString() });
    }
    if (action === "addOrders") {
      const added = addOrders(params.orders || []);
      return json({ ok: true, added: added });
    }
    if (action === "updateStatus") {
      updateOrderStatus(params.orderId, params.status);
      return json({ ok: true });
    }
    if (action === "deleteOrder") {
      deleteOrder(params.orderId);
      return json({ ok: true });
    }
    throw new Error("Unknown action: " + action);
  } catch (err) {
    return json({ ok: false, error: err.message });
  }
}

function json(obj) {
  return ContentService
    .createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}

// ============================================================
// INVENTORY
// ============================================================
function getInventoryData() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const sheet = ss.getSheetByName(INVENTORY_SHEET);
  if (!sheet) {
    throw new Error("Sheet '" + INVENTORY_SHEET + "' nahi mili. Tab name check karo.");
  }

  const values = sheet.getDataRange().getValues();
  if (values.length < 2) return [];

  const headers = values[0].map(function(h) { return String(h).trim(); });
  const colIdx = {};
  for (const key in INVENTORY_COLUMNS) {
    const idx = headers.indexOf(INVENTORY_COLUMNS[key]);
    if (idx === -1) throw new Error("Column '" + INVENTORY_COLUMNS[key] + "' nahi mili.");
    colIdx[key] = idx;
  }

  const items = [];
  for (let i = 1; i < values.length; i++) {
    const row = values[i];
    const name = row[colIdx.name];
    if (!name) continue;
    items.push({
      name: String(name).trim(),
      stock: parseNum(row[colIdx.stock]),
      otw: parseNumOrNull(row[colIdx.otw])
    });
  }
  return items;
}

// ============================================================
// ORDERS
// ============================================================
function getOrdersSheet() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sheet = ss.getSheetByName(ORDERS_SHEET);
  if (!sheet) {
    // Auto-create Orders sheet with headers
    sheet = ss.insertSheet(ORDERS_SHEET);
    sheet.appendRow(ORDERS_HEADERS);
    const headerRange = sheet.getRange(1, 1, 1, ORDERS_HEADERS.length);
    headerRange.setFontWeight("bold");
    headerRange.setBackground("#fef3c7");
    sheet.setFrozenRows(1);
    sheet.setColumnWidth(1, 200); // Order ID
    sheet.setColumnWidth(2, 140); // Date
    sheet.setColumnWidth(3, 400); // Item Name
    sheet.setColumnWidth(4, 180); // Model
    sheet.setColumnWidth(5, 90);  // Quantity
    sheet.setColumnWidth(6, 110); // Status
    sheet.setColumnWidth(7, 200); // Notes
  }
  return sheet;
}

function getOrders() {
  const sheet = getOrdersSheet();
  const values = sheet.getDataRange().getValues();
  if (values.length < 2) return [];

  const headers = values[0];
  const cols = {
    id:     headers.indexOf("Order ID"),
    date:   headers.indexOf("Date"),
    name:   headers.indexOf("Item Name"),
    model:  headers.indexOf("Model"),
    qty:    headers.indexOf("Quantity"),
    status: headers.indexOf("Status"),
    notes:  headers.indexOf("Notes")
  };

  const orders = [];
  for (let i = 1; i < values.length; i++) {
    const row = values[i];
    if (!row[cols.id]) continue;
    const dateVal = row[cols.date];
    orders.push({
      id: String(row[cols.id]),
      date: dateVal instanceof Date ? dateVal.toISOString() : String(dateVal),
      name: String(row[cols.name] || ""),
      model: String(row[cols.model] || ""),
      qty: parseNum(row[cols.qty]),
      status: String(row[cols.status] || "Pending"),
      notes: String(row[cols.notes] || "")
    });
  }
  // Newest orders first
  orders.sort(function(a, b) { return (b.date || "").localeCompare(a.date || ""); });
  return orders;
}

function addOrders(orderList) {
  if (!orderList || orderList.length === 0) {
    throw new Error("Cart khali hai");
  }

  const sheet = getOrdersSheet();
  const now = new Date();
  // ONE Order ID for the whole cart submission (all items share it)
  const orderId = "ORD-" + now.getTime();

  const rows = orderList.map(function(o) {
    return [
      orderId,        // same ID for every item in this order
      now,
      String(o.name || ""),
      String(o.model || ""),
      parseNum(o.qty),
      "Pending",
      String(o.notes || "")
    ];
  });

  const startRow = sheet.getLastRow() + 1;
  sheet.getRange(startRow, 1, rows.length, ORDERS_HEADERS.length).setValues(rows);

  return rows.length;
}

function updateOrderStatus(orderId, status) {
  if (!orderId) throw new Error("orderId missing");
  if (VALID_STATUSES.indexOf(status) === -1) {
    throw new Error("Invalid status: " + status);
  }

  const sheet = getOrdersSheet();
  const values = sheet.getDataRange().getValues();
  const headers = values[0];
  const idIdx = headers.indexOf("Order ID");
  const statusIdx = headers.indexOf("Status");

  // Update ALL rows that share this Order ID
  let updated = 0;
  for (let i = 1; i < values.length; i++) {
    if (String(values[i][idIdx]) === String(orderId)) {
      sheet.getRange(i + 1, statusIdx + 1).setValue(status);
      updated++;
    }
  }
  if (updated === 0) throw new Error("Order not found: " + orderId);
  return updated;
}

function deleteOrder(orderId) {
  if (!orderId) throw new Error("orderId missing");
  const sheet = getOrdersSheet();
  const values = sheet.getDataRange().getValues();
  const headers = values[0];
  const idIdx = headers.indexOf("Order ID");

  // Collect rows to delete (from bottom up to avoid index shift)
  const rowsToDelete = [];
  for (let i = 1; i < values.length; i++) {
    if (String(values[i][idIdx]) === String(orderId)) {
      rowsToDelete.push(i + 1);
    }
  }
  if (rowsToDelete.length === 0) {
    throw new Error("Order not found: " + orderId);
  }
  for (let j = rowsToDelete.length - 1; j >= 0; j--) {
    sheet.deleteRow(rowsToDelete[j]);
  }
  return rowsToDelete.length;
}

// ============================================================
// HELPERS
// ============================================================
function parseNum(v) {
  if (v === "" || v === null || v === undefined) return 0;
  const n = Number(v);
  return isNaN(n) ? 0 : n;
}

function parseNumOrNull(v) {
  if (v === "" || v === null || v === undefined) return null;
  const n = Number(v);
  return isNaN(n) ? null : n;
}

// ============================================================
// TEST FUNCTIONS — run from Apps Script editor to verify
// ============================================================
function testInventory() {
  const data = getInventoryData();
  Logger.log("Total items: " + data.length);
  Logger.log("First 3: " + JSON.stringify(data.slice(0, 3), null, 2));
}

function testOrders() {
  const orders = getOrders();
  Logger.log("Total orders: " + orders.length);
  Logger.log("Orders: " + JSON.stringify(orders, null, 2));
}
